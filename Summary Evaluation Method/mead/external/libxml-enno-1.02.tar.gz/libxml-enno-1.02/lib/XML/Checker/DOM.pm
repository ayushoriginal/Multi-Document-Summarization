BEGIN
{
    warn "XML::Checker::DOM has been deprecated. The methods have been merged into XML::DOM."
}
