This directory contains test cases that can be run with: make test 
from the parent of this directory. (Note that you must first run: make install)

- dom_*.t	Test cases for XML::DOM
- xql_*.t	Test cases for XML::XQL
- chk_*.t	Test cases for XML::Checker
- *.xml		XML files used by chk_batch.t
- out/*.err	Expected output for the test cases in chk_batch.t
